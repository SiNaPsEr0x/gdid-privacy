param(
    [ValidateSet('rotate')]
    [string]$Mode = 'rotate'
)

$ErrorActionPreference = 'Stop'

try {
    & (Join-Path $PSScriptRoot 'gdid-tool.ps1') rotate *> $null
    if (-not $?) {
        throw 'GDID rotation failed'
    }
    exit 0
}
catch {
    # Task Scheduler records the result code; do not log the device identifier.
    exit 1
}
