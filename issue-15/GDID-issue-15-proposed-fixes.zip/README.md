# GDID Issue #15: portable proposed fixes

This archive is a proposed patch for `someguy0110/gdid-privacy` at commit
`6f2604b4bf6a59ec9244233a536bca5f0eee35ad` (2026-10-12). It is not an
upstream release. It contains no `gdid-config.json` or device identifiers.

## Contents

- `gdid-tool.ps1`: upstream script with a portable runner target and persistent
  service-start backups under `HKLM:\SOFTWARE\GDIDPrivacy\OriginalServiceStart`.
- `GDIDRotator-hidden.vbs`: upstream's portable, optional hidden launcher.
- `GDIDRotator-runner.ps1`: invokes rotation, suppresses identifier output and
  returns exit code 0 or 1 to Task Scheduler.
- `issue-15.patch`: changes relative to the commit above.

## Changes relative to upstream

The current upstream already includes interactive-user logon scheduling, a
bounded timed trigger, local registry verification, CDP service stopping, and
an optional hidden launcher. This patch points the task at the runner and
persists the pre-install CDPSvc, CDPUserSvc template, and optional DoSvc startup
values across separate install and uninstall invocations. Reinstall preserves
the original values. If a prior install already disabled a service, that
disabled setting is what the backup captures; the patch cannot infer an older
setting. It also removes unsupported claims that local registry masking proves
a remote device identity change.

## Review and testing

Review the diff before use. Keep the scripts together in an administrator-writable
directory that ordinary users cannot modify. The task runs elevated; do not
install these scripts from a user-writable directory. Back up the current
configuration and service settings before replacing any existing installation.
Run `install` only from an elevated PowerShell session, then inspect the single
`GDIDRotator` task's action, principal, triggers, LastTaskResult and NextRunTime.
Test the logged-in user's HKCU value and service state before and after a task
run. `perBoot` currently means **at user logon**, because GDID is stored in
HKCU. The launcher requires Windows Script Host; the PowerShell action is the
fallback if it is unavailable.

Static syntax checks were run on PowerShell 5.1 and 7.6.6. No installation,
registry write, service change, reboot, or scheduled task execution was
performed as part of preparing this archive. A successful local registry write
does not prove that a remote service has accepted a changed device identity.
